<?php

namespace app\console\base;

use app\web\base\Request as BaseRequest;

class Request extends BaseRequest
{
    // we could implement logic that  is using $argv and $argc to get the command line arguments

}