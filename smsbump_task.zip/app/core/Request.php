<?php

namespace app\core;

/**
 * Request is the base class for both web and console request classes.
 */
abstract class Request
{


}