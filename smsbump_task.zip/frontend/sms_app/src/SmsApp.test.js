import { render, screen } from '@testing-library/react';
import SmsApp from './SmsApp';


