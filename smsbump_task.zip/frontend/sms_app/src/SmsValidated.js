import React from 'react';
class SmsValidated extends React.Component {
  render() {
    return (
      <div>
        <p>Validated</p>
      </div>
    );
  }
}
export default SmsValidated;